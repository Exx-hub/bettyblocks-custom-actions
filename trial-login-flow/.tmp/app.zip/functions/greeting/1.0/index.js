const greeting = async () => {

}

export default greeting;